from .common import ROOT, read


def report():
    summary = read(ROOT / "results/summaries/summary.json")
    lines = ["# Executed results", "", "Generated from actual local measurements; no estimated values.", "",
             "Hardware: " + read(ROOT / "results/hardware.json")["cpu"] + "; NVIDIA RTX 4050 Laptop GPU, 6 GiB; Windows; existing CUDA torch preserved.", "",
             "Dataset validation: 5,183 corpus documents; 300 dev claims, of which 188 have evidence annotations and 112 are excluded from quality averages. No test-set evaluation.", "",
             "## Full-corpus warm trials", "",
             "| Configuration | Trials | Doc embedding mean ± SD (s) | Rebuilt pipeline (s) | Embedding speedup | Pipeline speedup | Single query mean (ms) | Effective loader workers |",
             "|---|---:|---:|---:|---:|---:|---:|---:|"]
    for name, r in summary.items():
        if r["workload"]["documents"] != 5183 or r["workload_kind"] != "real_unique_documents":
            continue
        s, speed = r["statistics"], r.get("speedups", {})
        e = s["document_embedding_s"]
        lines.append(f"| {name} | {e['n']} | {e['mean']:.3f} ± {(e['std'] or 0):.3f} | {s['end_to_end_s']['mean']:.3f} | {speed.get('document_embedding_s', 0):.3f}× | {speed.get('end_to_end_s', 0):.3f}× | {s['single_latency_mean_s']['mean'] * 1000:.3f} | {r.get('effective_loader_workers')} |")
    lines.extend(["", "Times are full-corpus rebuilt warm measurements. Cold startup and per-stage timings are saved separately. CUDA speedups are heterogeneous. CPU embedding efficiency divides by native compute threads, not preprocessing workers.", "",
                  "## Retrieval effectiveness", "", "| Configuration | Recall@1 | Recall@5 | Recall@10 | MRR (full corpus) | nDCG@10 |", "|---|---:|---:|---:|---:|---:|"])
    for name, r in summary.items():
        if r["workload"]["documents"] != 5183:
            continue
        m = r["quality"].get("metrics")
        if m:
            lines.append("| " + name + " | " + " | ".join(f"{m[k]:.6f}" for k in ("recall@1", "recall@5", "recall@10", "mrr", "ndcg@10")) + " |")
    lines.extend(["", "## Files and handoff", "", "- Raw trials, cold timings, latency samples, quality and hardware metadata: `results/raw/<run>/`.",
                  "- Mean, SD, median and Student-t 95% CIs: `results/summaries/summary.json` and `.csv`.",
                  "- Figures: `results/plots/*.png` and `*.pdf`.",
                  "- Real fixed Member B output: `examples/retrieval_output.json`; import `retrieve` from `retrieval.py`.",
                  "- Dataset/model provenance: `data/manifests/`; saved index/vectors/IDs: `artifacts/<run>/`.", "",
                  "## Limitations", "", "Single-laptop measurements, incomplete relevance annotations, 256-token document truncation, sampled RAM, fixed configuration order, and SciFact's small size limit generalization. Native Windows FAISS is CPU only. CUDA search uses PyTorch, not FAISS GPU. Worker reductions and OOM changes appear in metadata. No WSL, second environment, SciFact-Open download, or Member B classifier is included. See METHODOLOGY.md for exact protocols."])
    target = ROOT / "docs/RESULTS.md"
    target.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return str(target)
